package com.ey.jdbc.client;

import java.sql.SQLException;
import java.sql.Statement;

import com.training.JdbcDemo;
import com.ey.jdbc.model.ProductMain;
import com.ey.jdbc.service.product1Service;
import com.ey.jdbc.service.product1ServiceImpl;
import com.ey.jdbc.util.DbConn;

public class productClint {


	public static void main(String[] args) throws SQLException,ClassNotFoundException{
		
		product1Service pp=new product1ServiceImpl();
    
		
		
       
		//adding/inserting
		pp.insertProductMain(new ProductMain(141,"AC",67000));
		pp.insertProductMain(new ProductMain(142,"fridge",25000));
		pp.insertProductMain(new ProductMain(143,"Washing machine",30000));
		//listing
		pp.getAllProductMains().stream().forEach(e->System.out.println(e));;
		
		

	}

	

}